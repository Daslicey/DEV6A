﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntryPoint
{
    class Merge
    {
        private Vector2[] BuildingArray;
        private Vector2[] TempArray;
        private Vector2 House;
        private int length;

        public Merge(Vector2 House, IEnumerable<Vector2> specialBuildings)
        {
            this.BuildingArray = specialBuildings.ToArray();
            this.House = House;
            this.length = specialBuildings.Count();
            this.TempArray = new Vector2[length];
        }

        //split de specialbuildings array
        public void sort()
        {
            split(0, length-1);
        }

        private void split(int low, int high)
        {
            if (high > low)
            {
                int middle = low + (high - low) / 2;
                split(low, middle);
                split(middle + 1, high);
                merge(low, middle, high);
            }
        }

        //vergelijkt de gesplitste data en stopt ze in de goede volgorde om dan gemerged te worden.
        private void merge(int low, int middle, int high)
        {
            for (int l = low; l <= high; l++)
            {
                TempArray[l] = BuildingArray[l];
            }
            int x = low;
            int y = middle + 1;
            int z = low;
            while (x <= middle && y <= high)
            {
                if (calcDistance(TempArray[x]) <= calcDistance(TempArray[y]))
                {
                    BuildingArray[z] = TempArray[x];
                    x++;
                }
                else {
                    BuildingArray[z] = TempArray[y];
                    y++;
                }
                z++;
            }
            while (x <= middle)
            {
                BuildingArray[z] = TempArray[x];
                z++;
                x++;
            }
        }
        //berkent de afstand vanaf het huis tot alle special buildings
        private float calcDistance(Vector2 v)
        {
            return Vector2.Distance(v, this.House);
        }
        //de specialbuildig array
        public IEnumerable<Vector2> getList()
        {
            return this.BuildingArray;
        }
    }
}
