﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntryPoint
{
    class Dijkstra
    {

        private Vector2 startBuilding;
        private Vector2 destBuilding;
        private IEnumerable<Tuple<Vector2, Vector2>> roads;

     

        public Dijkstra(Vector2 startBuilding,
          Vector2 destBuilding, IEnumerable<Tuple<Vector2, Vector2>> roads)
        {
            this.startBuilding = startBuilding;
            this.destBuilding = destBuilding;
            this.roads = roads;
            Vector2 v = new Vector2(2, 2);
            foreach (Tuple<Vector2, Vector2> road in roads)
            {
                
                if(road.Item1 == v || road.Item2 == v)
                    Console.WriteLine(road);
            }
        }

        public IEnumerable<Tuple<Vector2, Vector2>> result()
        {
            var startRoad = roads.Where(x => x.Item1.Equals(startBuilding)).First();
            List<Tuple<Vector2, Vector2>> lastBestPath = new List<Tuple<Vector2, Vector2>>() { startRoad };
            var previousRoad = startRoad;
            for (int i = 0; i < 1000; i++)
            {
                previousRoad = (roads.Where(x => x.Item1.Equals(previousRoad.Item2)).OrderBy(x => Vector2.Distance(x.Item2, destBuilding)).First());
                lastBestPath.Add(previousRoad);
            }
            return lastBestPath;
        }
    }
}
